﻿using System;
using System.IO;
using System.Xml.Serialization;

namespace WebApplication1
{
    public class Utility
    {
        public static T FromXml<T>(string xml)
        {
            T returnXmlClass = default(T);
            try
            {
                //using (TextReader reader = new StreamReader(xml,))
                //{

                //    returnXmlClass = (T)new XmlSerializer(typeof(T)).Deserialize(reader);

                //}

                using (var stringReader = new StringReader(xml))
                {
                    var serializer = new XmlSerializer(typeof(T));
                    returnXmlClass=(T)serializer.Deserialize(stringReader);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnXmlClass;
        }

        public static string ApiBaseUrl = "https://www.crcind.com/csp/samples/SOAP.Demo.cls?";
    }
}
