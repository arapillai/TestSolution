﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Repository
{
    public class ProfileManager : IDataRepository<Profile>
    {
        readonly ProfileContext _employeeContext;

        public ProfileManager(ProfileContext context)
        {
            _employeeContext = context;
        }

        public void Add(Profile entity)
        {
            _employeeContext.Profiles.Add(entity);
            _employeeContext.SaveChanges();
        }

    }
}
