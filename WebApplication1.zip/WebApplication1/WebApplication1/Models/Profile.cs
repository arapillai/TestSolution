﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WebApplication1.Models
{
    [Table("Profile")]
    [XmlRoot(ElementName = "FindPersonResult", Namespace = "http://tempuri.org")]
    public class Profile
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [XmlElement("Name")]
        public string Name { get; set; }

        [XmlElement("SSN")]
        public string SSN { get; set; }

        [XmlElement("DOB")]
        public string DOB { get; set; }

        [XmlElement("Age")]
        public string Age { get; set; }
    }
}
