﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WebApplication1.Models
{
    public class PersonIdentification
    {
        [XmlElement("ID")]
        public int ID { get; set; }

        [XmlElement("Name")]
        public string Name { get; set; }

        [XmlElement("SSN")]
        public string SSN { get; set; }

        [XmlElement("DOB")]
        public string DOB { get; set; }
    }

    [XmlRoot(ElementName = "GetListByNameResult", Namespace = "http://tempuri.org")]
    public class Person
    {
        [XmlElement("PersonIdentification")]
        public List<PersonIdentification> PersonIdentification { get; set; }
    }
}
