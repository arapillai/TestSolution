﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfileApiController : ControllerBase
    {
        private readonly IDataRepository<Profile> _dataRepository;
        public ProfileApiController(IDataRepository<Profile> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        // POST: api/Employee
        [HttpPost]
        public IActionResult Post([FromBody] Profile profile)
        {
            if (profile == null)
            {
                return BadRequest("profile is null.");
            }

            _dataRepository.Add(profile);
            return CreatedAtRoute(
                  "Get",
                  new { Id = profile.Id },
                  profile);
        }

    }
}
