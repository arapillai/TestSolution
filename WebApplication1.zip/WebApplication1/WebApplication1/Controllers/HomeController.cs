﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProfileApiService _profileApiService;
        private readonly IPersonApiService _personApiService;

        public HomeController(IPersonApiService personApiService, IProfileApiService profileApiService)
        {
            _personApiService = personApiService;
            _profileApiService = profileApiService;
        }

        public async Task<IActionResult> Index(string name)
        {
            ViewData["SearchName"] = name;

            var person = await _personApiService.GetListByName(name);

            return View(person);
        }

        public async Task<IActionResult> Profile(int id)
        {
            ViewData["SearchId"] = id;

            var profile = await _profileApiService.FindPerson(id);

            return View(profile);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
