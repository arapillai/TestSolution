﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml.Linq;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class ProfileApiService : IProfileApiService
    {
        XNamespace nSpace = "http://tempuri.org";

        public async Task<Profile> FindPerson(int id)
        {
            return await FindPersonById(id);
        }

        private async Task<Profile> FindPersonById(int id)
        {
            try
            {
                using (var httpClient = new HttpClient(new HttpClientHandler() { AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip }) { Timeout = TimeSpan.FromSeconds(90) })
                {
                    var responseTask = await httpClient.GetAsync(Utility.ApiBaseUrl + "soap_method=FindPerson&id=" + id);

                    if (responseTask.StatusCode == HttpStatusCode.OK)
                    {
                        var readTask = await responseTask.Content.ReadAsStreamAsync();

                        XDocument doc = XDocument.Load(readTask);

                        var xElement = doc.Descendants(nSpace + "FindPersonResult").FirstOrDefault();

                        if(xElement!=null)
                        {
                            var profile = Utility.FromXml<Profile>(xElement.ToString());

                            return profile;
                        }

                        return null;
                    }
                    else
                        return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
