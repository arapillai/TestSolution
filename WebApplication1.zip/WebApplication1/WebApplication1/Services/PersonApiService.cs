﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml.Linq;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class PersonApiService : IPersonApiService
    {
        XNamespace nSpace = "http://tempuri.org";

        public async Task<Person> GetListByName(string name)
        {
            return await GetListByNameRequest(name);
        }

        private async Task<Person> GetListByNameRequest(string personName)
        {
            try
            {
                using (var httpClient = new HttpClient(new HttpClientHandler() { AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip }) { Timeout = TimeSpan.FromSeconds(90) })
                {
                    var responseTask = await httpClient.GetAsync(Utility.ApiBaseUrl + "soap_method=GetListByName&name=" + personName);

                    if (responseTask.StatusCode == HttpStatusCode.OK)
                    {
                        var readTask = await responseTask.Content.ReadAsStreamAsync();

                        XDocument doc = XDocument.Load(readTask);

                        var xmlResult = doc.Descendants(nSpace + "GetListByNameResult").FirstOrDefault().ToString();

                        var nameResult = Utility.FromXml<Person>(xmlResult);

                        return nameResult;
                    }
                    else
                        return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
